package de.eggheads.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.assertj.core.util.Arrays;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TestUtil {
	private static String longString = null;
	private static String shortString = null;
	private static List<String> words = new ArrayList<>();

	public static long getStart() {
		return new Date().getTime();
	}

	public static long getTimeFinished(long start) {

		return new Date().getTime() - start;
	}

	public static String getLongString() {
		if (longString == null)
			try (BufferedReader reader = new BufferedReader(new FileReader("long.xml"))) {
				String s = null;
				longString = "";
				while ((s = reader.readLine()) != null)
					longString += s;
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}

		return longString;

	}

	public static String getShortString() {
		if (shortString == null)
			try (BufferedReader reader = new BufferedReader(new FileReader("short.csv"))) {
				String s = null;
				shortString = "";
				while ((s = reader.readLine()) != null)
					shortString += s;
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}

		return shortString;
	}

	public static List<String> getListOfRandomStrings(int amount, int maxSize) {

		List<String> list = new ArrayList<>();
		if (words.isEmpty())
			try (BufferedReader reader = new BufferedReader(new FileReader("ipsum.txt"))) {
				String s = null;
				while ((s = reader.readLine()) != null)
					Collections.addAll(words, s.split(" "));
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		for (int i = 0; i < amount; i++) {
			String s = getRandomString(maxSize);
			list.add(s);
		}
		return list;

	}

	public static String getRandomString(int maxSize) {
		int r = (int) (Math.random() * maxSize);
		String s = "";
		for (int j = 0; j < r; j++) {
			int wordsForLine = (int) (Math.random() * words.size());
			s += " " + words.get(wordsForLine);
		}
		return s;
	}

	public static Node getDoc(List<String> tEST_LIST_LONG, boolean hash) throws ParserConfigurationException {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.newDocument();
		Element root = doc.createElement("TEST");
		for (String s : tEST_LIST_LONG) {
			Element e = doc.createElement("CHILD");
			if (hash)
				e.setTextContent(s.hashCode() + "");
			else
				e.setTextContent(s);
			root.appendChild(e);
		}
		return root;
	}

	public static List getList(List<String> testList, boolean hash) {
		List list = new ArrayList();
		for (String s : testList) {
			list.add(getString(hash, s));
		}

		return list;
	}

	public static Object getString(boolean hash, String s) {
		if (hash)
			return new String(s).hashCode();
		else
			return new String(s);
	}

}

package de.eggheads.test;

import java.util.ArrayList;
import java.util.Collections;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import de.eggheads.test.event.Session;
import de.eggheads.test.node.ImportBatch;
import de.eggheads.test.request.ImportRequest;
import de.eggheads.test.service.TransformationService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)

public class ComparingHashTest {

	private ImportBatch test;
	@Autowired
	private TransformationService transformService;

	@Before
	private void setUp() {
		ImportRequest importRequest = new ImportRequest();
		importRequest.setData(TestUtil.getShortString());
		importRequest.setIdName("H7");
		importRequest.setImportType("TEST");
		importRequest.setConnectionElements(new ArrayList<>());
		Session s = Session.builder().events(Collections.EMPTY_LIST).status(0).build();
		ImportBatch batch = transformService.transformBatch(importRequest, s, true);

	}

}

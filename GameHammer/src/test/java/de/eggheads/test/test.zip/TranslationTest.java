package de.eggheads.test;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import de.eggheads.test.repositories.NodeRepository;

@RunWith(MockitoJUnitRunner.class)
public class TranslationTest {
	@Mock
	protected NodeRepository nodeRepository;

	@Before
	public void setUp() throws Exception {
		when(nodeRepository.getOne(null));

	}

	@Test
	public void testExecute() {
		fail("Not yet implemented");
		// script.run(Arrays.asList(node).toArray());
	}
}

package de.eggheads.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import de.eggheads.test.node.NodeValue;
import lombok.extern.slf4j.Slf4j;

/**
 * TODO:Optimizing tests with large amount of small strings and taking
 * time.(Durchschnitt,Standardabweichung usw.,min und max)*
 *
 * @author s.sadegh
 *
 */
@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)

public class NodeTestV2 {
	private static final String CSV_SEPERATOR = ";";
	private static int TEST_PER_LENGTH = 50;

	private long compareHash(List<Integer> node, List<String> test) throws ParserConfigurationException {
		long start = TestUtil.getStart();
		for (int i = 0; i < node.size(); i++)
			assertTrue(node.get(i) == test.get(i).hashCode());
		return TestUtil.getTimeFinished(start);
	}

	private long compareString(List<String> node, List<String> test) throws ParserConfigurationException {
		long start = TestUtil.getStart();
		for (int i = 0; i < node.size(); i++)
			assertTrue(node.get(i).equals(test.get(i)));
		return TestUtil.getTimeFinished(start);
	}

	public void test_and_fill_csv() throws ParserConfigurationException {
		try (PrintWriter bR = new PrintWriter(new FileWriter("test_" + new Date().getTime() + ".csv"))) {
			bR.println("SIZE_OF_LIST;AVG_ELEMENT_SIZE;TYPE;TIME");
			for (int i = 0; i < TEST_PER_LENGTH; i++) {
				List<String> testList = TestUtil.getListOfRandomStrings(25000, 200);
				List<String> testString = TestUtil.getList(testList, false);
				int avg = getAverageSize(testList);
				long timeString = compareString(testString, testList);
				bR.println(
						testList.size() + CSV_SEPERATOR + avg + CSV_SEPERATOR + "STRING" + CSV_SEPERATOR + timeString);
			}
			for (int i = 0; i < TEST_PER_LENGTH; i++) {
				List<String> testList = TestUtil.getListOfRandomStrings(25000, 200);
				List<Integer> testString = TestUtil.getList(testList, true);
				int avg = getAverageSize(testList);
				long timeString = compareHash(testString, testList);
				bR.println(testList.size() + CSV_SEPERATOR + avg + CSV_SEPERATOR + "HASH" + CSV_SEPERATOR + timeString);
			}
			for (int i = 0; i < TEST_PER_LENGTH; i++) {
				List<String> testList = TestUtil.getListOfRandomStrings(25000, 500);
				List<String> testString = TestUtil.getList(testList, false);
				int avg = getAverageSize(testList);
				long timeString = compareString(testString, testList);
				bR.println(
						testList.size() + CSV_SEPERATOR + avg + CSV_SEPERATOR + "STRING" + CSV_SEPERATOR + timeString);
			}
			for (int i = 0; i < TEST_PER_LENGTH; i++) {
				List<String> testList = TestUtil.getListOfRandomStrings(25000, 500);
				List<Integer> testString = TestUtil.getList(testList, true);
				int avg = getAverageSize(testList);
				long timeString = compareHash(testString, testList);
				bR.println(testList.size() + CSV_SEPERATOR + avg + CSV_SEPERATOR + "HASH" + CSV_SEPERATOR + timeString);
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	private int getAverageSize(List<String> testList) {
		int sum = 0;
		for (String s : testList) {
			sum += s.length();
		}
		return sum / testList.size();
	}

}

package de.eggheads.test.configuration;

import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import de.eggheads.test.service.ZlipCompressorService;

@Profile("test")
@Configuration
public class ZlipCompressorTestConfiguration {
	@Bean
	@Primary
	public ZlipCompressorService nameService() {
		return Mockito.mock(ZlipCompressorService.class);
	}
}
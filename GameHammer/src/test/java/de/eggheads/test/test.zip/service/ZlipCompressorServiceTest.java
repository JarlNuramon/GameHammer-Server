package de.eggheads.test.service;

import static org.mockito.Mockito.*;

import java.io.UnsupportedEncodingException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import de.eggheads.test.TestUtil;
import de.eggheads.test.service.ZlipCompressorService.Compressed;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
class ZlipCompressorServiceTest {
	private final static String TEST_SHORT = "Hello World";
	private final String TEST_LONG = "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.";

	@TestConfiguration
	public class ZlipCompressorTestConfiguration {
		@Bean

		public ZlipCompressorService zlip() {
			return new ZlipCompressorService();
		}
	}

	@Autowired
	private ZlipCompressorService zlip;

	@Test
	void short_string_compression() throws UnsupportedEncodingException {
		zlip = new ZlipCompressorService();
		Compressed comp = zlip.deflate(TEST_SHORT);
		log.info("ompressed {}", new String(comp.getBytes(), "UTF-8"));
		String decompressed = zlip.inflate(comp);
		assertTrue(TEST_SHORT.equals(decompressed));

	}

	@Test
	void long_string_compression() {
		zlip = new ZlipCompressorService();
		Compressed comp = zlip.deflate(TEST_LONG);
		String decompressedLong = zlip.inflate(comp);
		assertTrue(TEST_LONG.equals(decompressedLong));
	}

	@Test
	void long_checksum() {
		zlip = new ZlipCompressorService();
		int checksum = zlip.getCheckSum(TEST_LONG);
		log.info("Reduced by {}", -1 * (Integer.toString(checksum).getBytes().length - TEST_LONG.getBytes().length));
		assertTrue(Integer.toString(checksum).getBytes().length < TEST_LONG.getBytes().length);
	}

	@Test
	void short_checksum() {
		zlip = new ZlipCompressorService();
		int checksum = zlip.getCheckSum(TEST_SHORT);
		log.info("Reduced by {}", -1 * (Integer.toString(checksum).getBytes().length - TEST_SHORT.getBytes().length));
		assertTrue(Integer.toString(checksum).getBytes().length <= TEST_SHORT.getBytes().length);
	}

}
